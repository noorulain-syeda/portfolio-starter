// Inside the monitor: the whole CV on one page, in English or Arabic.
import Link from "next/link";
import { cv } from "@/data/cv";
import { ui } from "@/data/ui";
import { countOf, dirOf, fill, fmtMetric, fmtMonth, fmtNumber, fmtRange, fmtYear, otherLang, tr } from "@/lib/i18n";
import { withBase } from "@/lib/withBase";
import TopBar from "@/components/site/TopBar";
import CertList from "@/components/site/CertList";
import SiteFooter from "@/components/site/SiteFooter";

export async function generateMetadata({ params }) {
  const { lang } = await params;
  return {
    title: ui.siteTitle[lang],
    description: cv.summary[lang].split(/(?<=\.)\s/)[0],
    alternates: { languages: { en: "/en/", ar: "/ar/" } },
  };
}

function Section({ id, title, sub, children }) {
  return (
    <section id={id} className="section" aria-labelledby={`${id}-h`}>
      <div className="section-head">
        <h2 id={`${id}-h`}>{title}</h2>
        {sub ? <p>{sub}</p> : null}
      </div>
      {children}
    </section>
  );
}

export default async function PortfolioPage({ params }) {
  const { lang } = await params;
  const other = otherLang(lang);
  const S = ui.sections;
  const present = ui.present[lang];
  const arrow = lang === "ar" ? "←" : "→";
  const to = lang === "ar" ? "إلى" : "to";
  const q = (text) => (lang === "ar" ? `«${text}»` : `“${text}”`);

  return (
    <>
      <a className="skip-link" href="#work">
        {S.work[lang]}
      </a>
      <TopBar lang={lang} />

      <main className="wrap">
        {/* Hero: both names, facing each other. The page's language comes first. */}
        <section className="hero" aria-labelledby="name-h">
          <h1 id="name-h" className="names">
            <span>{cv.shortName[lang]}</span>
            <span className="names-line" aria-hidden="true" />
            <span className="other" lang={other} dir={dirOf(other)}>
              {cv.shortName[other]}
            </span>
          </h1>
          <p className="hero-role">{cv.title[lang].replaceAll(" | ", lang === "ar" ? "، " : ", ")}</p>
          <p className="hero-lede">{ui.heroLede[lang]}</p>
          <div className="actions">
            <a className="btn btn-primary" href={withBase(cv.cvFile)} download>
              {ui.downloadCv[lang]}
            </a>
            <a className="btn" href={`mailto:${cv.contact.email}`}>
              {ui.emailYara[lang]}
            </a>
          </div>
        </section>

        <Section id="glance" title={S.highlights[lang]}>
          <dl className="glance">
            {cv.highlights.map((h) => (
              <div key={h.text.en}>
                <dt>
                  <span dir="ltr">{h.value[lang]}</span>
                </dt>
                <dd>{h.text[lang]}</dd>
              </div>
            ))}
          </dl>
        </Section>

        <Section id="work" title={S.work[lang]} sub={S.workSub[lang]}>
          <ol className="ledger">
            {cv.projects.map((p) => {
              const m = p.metrics[0];
              return (
                <li key={p.slug}>
                  <Link href={`/${lang}/work/${p.slug}/`}>
                    <span>
                      <span className="ledger-name">{p.name[lang]}</span>
                      <span className="ledger-org">
                        {p.org[lang]}, {fmtYear(Number(p.start.slice(0, 4)), lang)}
                      </span>
                    </span>
                    <span className="ledger-label">{m.label[lang]}</span>
                    <span className="ledger-figure">
                      {m.from != null ? (
                        <>
                          <span className="ledger-from">{fmtMetric(m.from, m.unit, lang)}</span>
                          <span aria-hidden="true" className="ledger-from">
                            {arrow}
                          </span>
                          <span className="sr-only">{to}</span>
                        </>
                      ) : null}
                      <span className="ledger-to">{fmtMetric(m.to, m.unit, lang)}</span>
                    </span>
                  </Link>
                </li>
              );
            })}
          </ol>
        </Section>

        <Section id="experience" title={S.experience[lang]} sub={S.experienceSub[lang]}>
          <ol className="timeline">
            {cv.experience.map((x) => (
              <li key={x.id} className={x.id === "career-break" ? "is-break" : undefined}>
                <h3>
                  {x.role[lang]}
                  {x.org ? <span className="muted">{lang === "ar" ? "، " : ", "}{x.org[lang]}</span> : null}
                </h3>
                <p className="when">
                  {fmtRange(x.start, x.end, lang, present)} · {x.place[lang]}
                </p>
                <ul>
                  {x.points.map((pt) => (
                    <li key={pt.en}>{pt[lang]}</li>
                  ))}
                </ul>
                {x.tech.length ? (
                  <ul className="chips" aria-label="Technologies">
                    {x.tech.map((tech) => (
                      <li key={tech} dir="ltr">
                        {tech}
                      </li>
                    ))}
                  </ul>
                ) : null}
              </li>
            ))}
          </ol>
        </Section>

        <Section id="skills" title={S.skills[lang]}>
          <div className="skills">
            {cv.skills.map((s) => (
              <div key={s.group.en}>
                <h3>{s.group[lang]}</h3>
                <p className="meta">
                  {ui.levels[s.level][lang]}, {countOf(s.years, "years", lang)}
                </p>
                <p>{s.items.map((i) => tr(i, lang)).join(lang === "ar" ? "، " : ", ")}</p>
              </div>
            ))}
          </div>
        </Section>

        <Section id="research" title={S.research[lang]}>
          <p className="prose">
            <Link href={`/${lang}/work/khatt/`}>{ui.tryKhatt[lang]}</Link>
          </p>
          <h3 className="sub-h">{S.patents[lang]}</h3>
          <ul className="rows">
            {cv.patents.map((p) => (
              <li key={p.id}>
                <span className="title">{p.title[lang]}</span>
                <span className="side">{p.status[lang]}</span>
                <span className="detail">{p.number[lang]}</span>
              </li>
            ))}
          </ul>
          <h3 className="sub-h">{S.publications[lang]}</h3>
          <p className="muted" style={{ margin: "0 0 8px" }}>
            {fill(ui.shownOf[lang], { shown: fmtNumber(cv.publications.length, lang), total: fmtNumber(cv.publicationsTotal, lang) })}{" "}
            <a href={cv.contact.links.find((l) => l.label === "Google Scholar").url}>{ui.fullList[lang]}</a>
          </p>
          <ol className="citations" lang="en" dir="ltr">
            {cv.publications.map((p) => (
              <li key={p.id}>{p.citation}</li>
            ))}
          </ol>
        </Section>

        <Section id="recognition" title={S.recognition[lang]}>
          <h3 className="sub-h" style={{ marginTop: 0 }}>
            {S.awards[lang]}
          </h3>
          <ul className="rows">
            {cv.awards.map((a) => (
              <li key={a.id}>
                <span className="title">{a.name[lang]}</span>
                <span className="side">{fmtYear(a.year, lang)}</span>
                <span className="detail">
                  {a.by[lang]}. {a.project ? <Link href={`/${lang}/work/${a.project}/`}>{a.for[lang]}</Link> : a.for[lang]}
                </span>
              </li>
            ))}
          </ul>
          <h3 className="sub-h">{S.talks[lang]}</h3>
          <p className="muted" style={{ margin: "0 0 8px" }}>
            {fill(ui.shownOf[lang], { shown: fmtNumber(cv.talks.length, lang), total: fmtNumber(cv.talksTotal, lang) })}
          </p>
          <ul className="rows">
            {cv.talks.map((t) => (
              <li key={t.id}>
                <span className="title">
                  {ui.talkKinds[t.kind][lang]}: {q(t.title[lang])}
                </span>
                <span className="side">{fmtYear(t.year, lang)}</span>
                <span className="detail">
                  <span dir="ltr">{t.event}</span>, {t.city[lang]}
                </span>
              </li>
            ))}
          </ul>
          <h3 className="sub-h">{S.media[lang]}</h3>
          <ul className="rows">
            {cv.media.map((m) => (
              <li key={m.id}>
                <span className="title">
                  {m.kind[lang]}: {m.url ? <a href={m.url}>{m.title[lang]}</a> : q(m.title[lang])}
                </span>
                <span className="side">{m.ongoing ? `${fmtMonth(m.date, lang)} – ${present}` : fmtMonth(m.date, lang)}</span>
                <span className="detail">
                  <span dir="ltr">{m.outlet}</span>
                  {m.detail ? <>. {m.detail[lang]}</> : null}
                </span>
              </li>
            ))}
          </ul>
        </Section>

        <Section id="credentials" title={S.credentials[lang]}>
          <h3 className="sub-h" style={{ marginTop: 0 }}>
            {S.education[lang]}
          </h3>
          <ul className="rows">
            {cv.education.map((e) => (
              <li key={e.degree.en}>
                <span className="title">{e.degree[lang]}</span>
                <span className="side">{fmtRange(e.start, e.end, lang, present)}</span>
                <span className="detail">
                  {e.school[lang]}, {e.mode[lang]}
                  {e.details.map((d) => (
                    <span key={d.en} style={{ display: "block" }}>
                      {d[lang]}
                    </span>
                  ))}
                </span>
              </li>
            ))}
          </ul>
          <h3 className="sub-h">{S.certifications[lang]}</h3>
          <p className="muted" style={{ margin: "0 0 12px" }}>
            {cv.certificationsNote[lang]}
          </p>
          <CertList certs={cv.certifications} lang={lang} />
        </Section>

        <Section id="giving-back" title={S.givingBack[lang]} sub={cv.givingBackNote[lang]}>
          <ul className="rows">
            {cv.givingBack.map((g) => (
              <li key={g.role.en}>
                <span className="title">
                  {g.role[lang]}
                  <span className="muted">{lang === "ar" ? "، " : ", "}{g.org[lang]}</span>
                </span>
                <span className="side">{fmtRange(g.start, g.end, lang, present)}</span>
                <span className="detail">{g.detail[lang]}</span>
              </li>
            ))}
          </ul>
        </Section>

        <Section id="about" title={S.about[lang]}>
          <p className="prose">{cv.summary[lang]}</p>
          <div className="split" style={{ marginTop: 24 }}>
            <div>
              <h3 className="sub-h" style={{ marginTop: 0 }}>
                {S.languages[lang]}
              </h3>
              <ul className="rows">
                {cv.languages.map((l) => (
                  <li key={l.name.en}>
                    <span className="title">{l.name[lang]}</span>
                    <span className="side">{l.level[lang]}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="sub-h" style={{ marginTop: 0 }}>
                {S.interests[lang]}
              </h3>
              <ul className="rows">
                {cv.interests.map((i) => (
                  <li key={i.en}>
                    <span className="title" style={{ fontWeight: 400 }}>
                      {i[lang]}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Section>

        <Section id="contact" title={S.contact[lang]}>
          <div className="split">
            <dl className="rows" style={{ margin: 0 }}>
              <div style={{ display: "contents" }}>
                <dt className="sr-only">{ui.email[lang]}</dt>
                <dd style={{ margin: 0, padding: "14px 0", borderTop: "1px solid var(--rule)" }}>
                  <a href={`mailto:${cv.contact.email}`} dir="ltr" style={{ fontSize: "var(--step-1)", fontWeight: 600 }}>
                    {cv.contact.email}
                  </a>
                </dd>
                <dt className="sr-only">{ui.phone[lang]}</dt>
                <dd style={{ margin: 0, padding: "14px 0", borderTop: "1px solid var(--rule)" }}>
                  <a href={`tel:${cv.contact.phone.replaceAll(" ", "")}`} dir="ltr">
                    {cv.contact.phone}
                  </a>
                </dd>
                <dt className="sr-only">{ui.location[lang]}</dt>
                <dd style={{ margin: 0, padding: "14px 0", borderTop: "1px solid var(--rule)" }}>{cv.location[lang]}</dd>
              </div>
            </dl>
            <div>
              <h3 className="sr-only">{ui.links[lang]}</h3>
              <ul className="chips" style={{ marginTop: 14 }} dir="ltr">
                {cv.contact.links.map((l) => (
                  <li key={l.label}>
                    <a href={l.url} style={{ textDecoration: "none", color: "var(--ink)" }}>
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
              <div className="actions" style={{ marginTop: 20 }}>
                <a className="btn btn-primary" href={withBase(cv.cvFile)} download>
                  {ui.downloadCv[lang]}
                </a>
              </div>
            </div>
          </div>
        </Section>
      </main>
      <SiteFooter lang={lang} />
    </>
  );
}
