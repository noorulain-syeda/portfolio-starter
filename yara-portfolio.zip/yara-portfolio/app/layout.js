import { plexSans, plexArabic, plexMono } from "@/lib/fonts";
import "./globals.css";

export const metadata = {
  title: "Yara Al-Mansouri | Portfolio",
  description:
    "Principal Product Engineer, Design Technology Lead and HCI researcher in Riyadh. Sixteen years building bilingual digital products.",
};

export const viewport = {
  themeColor: "#071631",
};

// Runs before the first paint: applies the saved light/dark choice and, on
// Arabic pages, sets lang="ar" dir="rtl" on <html> so nothing flips after load.
const bootScript = `(function(){try{var d=document.documentElement;var t=localStorage.getItem("theme");if(t==="dark"||t==="light")d.dataset.theme=t;if(/\\/ar(\\/|$)/.test(location.pathname)){d.lang="ar";d.dir="rtl";}}catch(e){}})();`;

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      dir="ltr"
      data-scroll-behavior="smooth"
      suppressHydrationWarning
      className={`${plexSans.variable} ${plexArabic.variable} ${plexMono.variable}`}
    >
      <head>
        <script dangerouslySetInnerHTML={{ __html: bootScript }} />
      </head>
      <body>{children}</body>
    </html>
  );
}
