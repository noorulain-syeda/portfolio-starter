import DeskEntry from "@/components/desk/DeskEntry";

export const metadata = {
  title: "Yara Al-Mansouri | Portfolio",
  description: "A desk in Riyadh. Click the screen to read Yara Al-Mansouri's portfolio in English or Arabic.",
};

export default function DeskPage() {
  return <DeskEntry />;
}
