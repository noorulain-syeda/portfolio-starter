"use client";

// The home route. Decides between the 3D desk and the plain idle screen,
// and owns everything that happens when a desk object is clicked.
import { useCallback, useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { cv } from "@/data/cv";
import { ui } from "@/data/ui";
import { withBase } from "@/lib/withBase";
import { applyTheme, currentTheme } from "@/lib/theme";
import { useDeskMode, useReducedMotion, useTheme } from "@/lib/hooks";
import { plexArabic, plexMono } from "@/lib/fonts";
import IdleScreenHtml from "./IdleScreenHtml";
import ThemeToggle from "@/components/site/ThemeToggle";

// three.js is only downloaded when the 3D desk is actually shown.
const DeskScene = dynamic(() => import("./DeskScene"), { ssr: false });

const preferredLang = () => (navigator.language?.toLowerCase().startsWith("ar") ? "ar" : "en");

export default function DeskEntry() {
  const router = useRouter();
  const mode = useDeskMode();
  const reduced = useReducedMotion();
  const theme = useTheme();
  const [veil, setVeil] = useState(false);
  const api = useRef(null);
  const leaving = useRef(false);

  useEffect(() => {
    document.documentElement.lang = "en";
    document.documentElement.dir = "ltr";
    router.prefetch("/en/");
    router.prefetch("/ar/");
  }, [router]);

  const go = useCallback(
    async (lang, hash = "") => {
      if (leaving.current) return;
      leaving.current = true;
      sessionStorage.setItem("desk:return", lang);
      if (!hash) await api.current?.flyIntoScreen();
      setVeil(true);
      setTimeout(() => router.push(`/${lang}/${hash}`), reduced ? 0 : 220);
    },
    [router, reduced]
  );

  const toggleTheme = useCallback(() => {
    applyTheme(currentTheme() === "dark" ? "light" : "dark");
  }, []);

  const downloadCv = useCallback(() => {
    const a = document.createElement("a");
    a.href = withBase(cv.cvFile);
    a.download = "";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, []);

  const onAction = useCallback(
    (action, detail) => {
      if (action === "enter") go(detail);
      else if (action === "drive") downloadCv();
      else if (action === "lamp") toggleTheme();
      else if (action === "plant") go(preferredLang(), "#giving-back");
      else if (action === "books") go(preferredLang(), "#research");
    },
    [go, downloadCv, toggleTheme]
  );

  return (
    <main className="desk" aria-labelledby="desk-h">
      <Link className="skip-link" href="/en/">
        {ui.desk.skip.en}
      </Link>
      <h1 id="desk-h" className="sr-only">
        {ui.desk.heading.en}
      </h1>

      {mode === "loading" && <p className="desk-loading">{ui.desk.loading.en}</p>}

      {mode === "html" && <IdleScreenHtml />}

      {mode === "3d" && (
        <>
          <DeskScene
            reduced={reduced}
            theme={theme}
            fonts={{ mono: plexMono.style.fontFamily, arabic: plexArabic.style.fontFamily }}
            onAction={onAction}
            onReady={(a) => (api.current = a)}
          />
          <nav className="desk-bar" aria-label={ui.desk.shortcuts.en}>
            <p className="desk-hint">
              <span>{ui.desk.hint.en}</span>
              <br />
              <span lang="ar" dir="rtl">
                {ui.desk.hint.ar}
              </span>
            </p>
            <div className="desk-actions">
              <button type="button" className="btn btn-primary" onClick={() => go("en")}>
                {ui.desk.enterEn.en}
              </button>
              <button type="button" className="btn btn-primary" lang="ar" onClick={() => go("ar")}>
                {ui.desk.enterAr.ar}
              </button>
              <button type="button" className="btn" onClick={downloadCv}>
                {ui.downloadCv.en}
              </button>
              <ThemeToggle lang="en" />
            </div>
          </nav>
        </>
      )}

      <div className="desk-veil" data-on={veil} aria-hidden="true" />
    </main>
  );
}
