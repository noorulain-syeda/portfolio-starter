"use client";

// The three.js part of the desk. One renderer for the life of the page,
// a transparent canvas (CSS paints the background), and no work while hidden.
import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { buildDesk } from "./buildDesk";
import { createIdleScreen } from "./idleScreen";
import { ui } from "@/data/ui";

const HOME_POS = new THREE.Vector3(0.24, 1.3, 1.82);
const HOME_TARGET = new THREE.Vector3(0.0, 0.93, 0);
const FLY_MS = 1100;

const ease = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);

export default function DeskScene({ reduced, theme, fonts, onAction, onReady }) {
  const mountRef = useRef(null);
  const tipRef = useRef(null);
  const stateRef = useRef(null);
  const handlers = useRef({ onAction, onReady });

  // Keep the latest callbacks without rebuilding the scene.
  useEffect(() => {
    handlers.current = { onAction, onReady };
  });

  useEffect(() => {
    const mount = mountRef.current;
    const tip = tipRef.current;
    let raf = 0;
    let tween = null;
    let hovered = null;

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    mount.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(35, 1, 0.05, 50);
    camera.position.copy(HOME_POS);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.copy(HOME_TARGET);
    controls.enablePan = false;
    controls.enableDamping = !reduced;
    controls.dampingFactor = 0.08;
    controls.minDistance = 1.1;
    controls.maxDistance = 3.4;
    controls.minPolarAngle = 0.95;
    controls.maxPolarAngle = 1.48;
    controls.minAzimuthAngle = -0.75;
    controls.maxAzimuthAngle = 0.75;

    const hemi = new THREE.HemisphereLight("#ffffff", "#7f95bd", 1.5);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight("#ffffff", 1.7);
    sun.position.set(1.8, 3.6, 2.6);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    Object.assign(sun.shadow.camera, { left: -1.6, right: 1.6, top: 1.6, bottom: -1.6, near: 0.5, far: 9 });
    sun.shadow.bias = -0.0005;
    sun.shadow.radius = 4;
    scene.add(sun);

    const desk = buildDesk();
    scene.add(desk.root);

    const idle = createIdleScreen({ monoFont: fonts.mono, arabicFont: fonts.arabic, reduced });
    desk.screen.material.map = idle.texture;
    desk.screen.material.needsUpdate = true;
    // Draw only once the fonts are ready, so the Arabic shapes correctly.
    let fontsReady = false;
    Promise.all([
      document.fonts.load(`500 40px ${fonts.mono}`),
      document.fonts.load(`600 48px ${fonts.arabic}`, "يارا"),
    ])
      .catch(() => {})
      .finally(() => {
        fontsReady = true;
        idle.restart();
      });

    // Materials of each clickable group, so hover can tint just that object.
    const hoverMats = new Map();
    for (const obj of desk.interactives) {
      if (obj.userData.action === "screen") continue;
      const mats = [];
      obj.traverse((m) => {
        if (m.isMesh && m.material?.emissive) {
          m.material = m.material.clone();
          mats.push(m.material);
        }
      });
      hoverMats.set(obj, mats);
    }

    function applyTheme(next) {
      const dark = next === "dark";
      hemi.intensity = dark ? 0.35 : 1.5;
      sun.intensity = dark ? 0.25 : 1.7;
      desk.lamp.light.intensity = dark ? 6 : 0;
      desk.lamp.bulb.emissiveIntensity = dark ? 2.2 : 0;
    }
    applyTheme(theme);

    function fitCamera() {
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      // Narrow windows: step back so the whole desk stays in view.
      camera.zoom = Math.min(1, camera.aspect / 1.45);
      camera.updateProjectionMatrix();
    }
    fitCamera();
    const ro = new ResizeObserver(fitCamera);
    ro.observe(mount);

    // Pointer handling: hover, tooltip, click (but not after a drag).
    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    let downAt = null;

    function pick(ev) {
      const r = renderer.domElement.getBoundingClientRect();
      ndc.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
      raycaster.setFromCamera(ndc, camera);
      const hit = raycaster.intersectObjects(desk.interactives, true)[0];
      if (!hit) return null;
      let obj = hit.object;
      while (obj && !obj.userData.action) obj = obj.parent;
      if (!obj) return null;
      const action = obj.userData.action;
      const half = action === "screen" && hit.uv ? (hit.uv.x < 0.5 ? "en" : "ar") : null;
      return { obj, action, half };
    }

    function setHovered(next, ev) {
      if (hovered && hovered.obj !== next?.obj) {
        for (const m of hoverMats.get(hovered.obj) || []) m.emissive.set("#000000");
      }
      if (next && hoverMats.has(next.obj)) {
        for (const m of hoverMats.get(next.obj)) {
          m.emissive.set("#2347c5");
          m.emissiveIntensity = 0.35;
        }
      }
      idle.setHover(next?.half ?? null);
      hovered = next;
      renderer.domElement.style.cursor = next ? "pointer" : "grab";
      if (next && ev) {
        const r = mount.getBoundingClientRect();
        tip.textContent =
          next.action === "screen" ? (next.half === "ar" ? ui.desk.enterAr.ar : ui.desk.enterEn.en) : ui.desk.tooltips[next.action];
        tip.style.left = `${ev.clientX - r.left}px`;
        tip.style.top = `${ev.clientY - r.top}px`;
        tip.hidden = false;
      } else if (!next) {
        tip.hidden = true;
      }
    }

    function onMove(ev) {
      if (tween || ev.pointerType === "touch") return;
      setHovered(pick(ev), ev);
    }
    function onDown(ev) {
      downAt = { x: ev.clientX, y: ev.clientY };
    }
    function onUp(ev) {
      if (!downAt || tween) return;
      const moved = Math.hypot(ev.clientX - downAt.x, ev.clientY - downAt.y);
      downAt = null;
      if (moved > 6) return;
      const hit = pick(ev);
      if (!hit) return;
      if (hit.action === "screen") handlers.current.onAction("enter", hit.half);
      else handlers.current.onAction(hit.action);
    }
    function onLeave() {
      setHovered(null);
    }
    const el = renderer.domElement;
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointerleave", onLeave);
    el.style.cursor = "grab";

    // Camera moves.
    const screenCenter = new THREE.Vector3();
    desk.screen.getWorldPosition(screenCenter);
    const closePos = screenCenter.clone().add(new THREE.Vector3(0, 0, 0.36));

    function moveCamera(toPos, toTarget, ms) {
      return new Promise((resolve) => {
        if (reduced || ms === 0) {
          camera.position.copy(toPos);
          controls.target.copy(toTarget);
          camera.lookAt(toTarget);
          resolve();
          return;
        }
        controls.enabled = false;
        const fromPos = camera.position.clone();
        const fromTarget = controls.target.clone();
        const t0 = performance.now();
        tween = (now) => {
          const k = Math.min(1, (now - t0) / ms);
          const e = ease(k);
          camera.position.lerpVectors(fromPos, toPos, e);
          controls.target.lerpVectors(fromTarget, toTarget, e);
          camera.lookAt(controls.target);
          if (k === 1) {
            tween = null;
            controls.enabled = true;
            resolve();
          }
        };
      });
    }

    // Coming back from the portfolio: start inside the screen and pull out.
    if (sessionStorage.getItem("desk:return") && !reduced) {
      camera.position.copy(closePos);
      controls.target.copy(screenCenter);
      moveCamera(HOME_POS, HOME_TARGET, FLY_MS);
    }
    sessionStorage.removeItem("desk:return");

    function loop(now) {
      raf = requestAnimationFrame(loop);
      if (document.hidden) return;
      if (tween) tween(now);
      else controls.update();
      if (fontsReady) idle.draw(now);
      renderer.render(scene, camera);
    }
    raf = requestAnimationFrame(loop);

    stateRef.current = { applyTheme };
    handlers.current.onReady?.({
      flyIntoScreen: () => moveCamera(closePos, screenCenter, FLY_MS),
    });

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointerleave", onLeave);
      controls.dispose();
      idle.dispose();
      scene.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        const m = o.material;
        if (Array.isArray(m)) m.forEach((x) => x.dispose());
        else if (m) m.dispose();
      });
      renderer.dispose();
      el.remove();
      stateRef.current = null;
    };
    // The scene is built once; theme changes are applied below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    stateRef.current?.applyTheme(theme);
  }, [theme]);

  return (
    <>
      <div ref={mountRef} className="desk-canvas" aria-hidden="true" />
      <div ref={tipRef} className="desk-tooltip" hidden aria-hidden="true" />
    </>
  );
}
