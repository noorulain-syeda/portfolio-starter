// The idle screen as plain HTML. Used on phones and when WebGL isn't available:
// the same choice (English or Arabic) without the 3D desk.
import Link from "next/link";
import { cv } from "@/data/cv";
import { ui } from "@/data/ui";
import { withBase } from "@/lib/withBase";

export default function IdleScreenHtml() {
  return (
    <div className="crt">
      <Link href="/en/" className="crt-half" lang="en" dir="ltr">
        <span className="crt-role">&gt; hello</span>
        <span className="crt-name">{cv.shortName.en}</span>
        <span className="crt-role">Principal Product Engineer, HCI researcher in Riyadh</span>
        <span className="crt-enter">{ui.desk.enterEn.en}</span>
      </Link>
      <div className="crt-rule" aria-hidden="true" />
      <Link href="/ar/" className="crt-half" lang="ar" dir="rtl">
        <span className="crt-role">مرحباً</span>
        <span className="crt-name">{cv.shortName.ar}</span>
        <span className="crt-role">مهندسة منتجات رئيسية، باحثة في التفاعل بين الإنسان والحاسوب في الرياض</span>
        <span className="crt-enter">{ui.desk.enterAr.ar}</span>
      </Link>
      <p className="crt-footer">
        <a href={withBase(cv.cvFile)} download>
          {ui.downloadCv.en}
        </a>
        <span aria-hidden="true">/</span>
        <a href={withBase(cv.cvFile)} download lang="ar">
          {ui.downloadCv.ar}
        </a>
      </p>
    </div>
  );
}
