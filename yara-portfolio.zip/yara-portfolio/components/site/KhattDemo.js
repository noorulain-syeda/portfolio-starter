"use client";

// A working sketch of Yara's patented idea: the same Arabic paragraph,
// tuned (or not) for the screen it is read on.
import { useId, useState } from "react";
import { ui } from "@/data/ui";
import { fill, fmtNumber } from "@/lib/i18n";

const WIDTH = { phone: 360, tablet: 620, desktop: 960 };
const TUNED = {
  phone: { size: 18, lh: 1.9, max: "100%", len: null },
  tablet: { size: 20, lh: 1.9, max: "32em", len: 32 },
  desktop: { size: 22, lh: 1.95, max: "34em", len: 34 },
};
const OFF = { size: 13, lh: 1.35, max: "none", len: null };

export default function KhattDemo({ lang }) {
  const [screen, setScreen] = useState("phone");
  const [on, setOn] = useState(true);
  const id = useId();
  const K = ui.khatt;
  const s = on ? TUNED[screen] : OFF;
  const text = { margin: 0, fontSize: `${s.size}px`, lineHeight: s.lh, maxWidth: s.max };

  const lenLabel = s.len ? `${fmtNumber(s.len, lang)} em` : K.unlimited[lang];

  return (
    <section className="panel" aria-labelledby={`${id}-h`}>
      <div className="khatt-controls">
        <h2 id={`${id}-h`} style={{ margin: 0, fontSize: "var(--step-2)", fontWeight: 600 }}>
          {K.title[lang]}
        </h2>
        <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <div className="seg" role="group" aria-label={K.screen[lang]}>
            {Object.keys(WIDTH).map((k) => (
              <button key={k} type="button" aria-pressed={screen === k} onClick={() => setScreen(k)}>
                {K.screens[k][lang]}
              </button>
            ))}
          </div>
          <button type="button" role="switch" aria-checked={on} className="btn btn-quiet" onClick={() => setOn(!on)}>
            {K.toggle[lang]}: {on ? K.on[lang] : K.off[lang]}
          </button>
        </div>
      </div>
      <div className="khatt-stage">
        <div className="khatt-frame" style={{ width: WIDTH[screen], padding: on ? 28 : 14 }} lang="ar" dir="rtl">
          <p style={{ ...text, marginBottom: on ? 16 : 6 }}>
            النص العربي على الشاشات يُكتب غالباً بحجم صغير وكثافة عالية، فيتعب القارئ قبل أن يصل إلى نهاية الفقرة، ويعود إلى السطر نفسه مرتين.
          </p>
          <p style={text}>
            يقيس محرّك «خط» حجم الشاشة وسياق القراءة، ثم يضبط حجم الخط والمسافة بين الأسطر وطول السطر، فتصبح القراءة أسرع وأقل خطأً، دون أن يمسّ اتصال الحروف.
          </p>
        </div>
      </div>
      <p className="readout">{fill(K.readout[lang], { size: fmtNumber(s.size, lang), lh: fmtNumber(s.lh, lang), len: lenLabel })}</p>
      <p className="muted" style={{ margin: "8px 0 0", fontSize: 15 }}>
        {K.note[lang]}
      </p>
    </section>
  );
}
