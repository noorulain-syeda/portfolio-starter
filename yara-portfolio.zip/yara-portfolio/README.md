# Yara Al-Mansouri · Portfolio Summit 2026

A 3D desk in the browser. Click the monitor and the camera flies into the screen:
the **left half opens the portfolio in English, the right half in Arabic**. Inside is
the whole CV, and one button mirrors the page between the two languages.

Built on the workshop starter: **Next.js 16 (App Router), JavaScript, three.js**, exported
as a static site for **GitHub Pages**.

## Run it

You need Node.js 20+.

```bash
npm install
npm run dev        # http://localhost:3000
npm run check:cv   # confirms every CV section is present, in both languages
npm run build      # static site in ./out (runs check:cv first)
```

## Deploy (GitHub Pages)

1. Push this folder to a GitHub repo (or replace the files in your starter fork).
2. Repo **Settings → Pages → Source: GitHub Actions**.
3. Push to `main`. The workflow in `.github/workflows/deploy.yml` builds and publishes to
   `https://<username>.github.io/<repo-name>/`.

The workflow sets `NEXT_PUBLIC_BASE_PATH` to `/<repo-name>`. Every link to a file in
`public/` (like the CV PDF) goes through `withBase()` so it keeps working there.

## Where things live

| Path | What it is |
| --- | --- |
| `data/cv.js` | Yara's whole CV. Every visible text is `{ en, ar }`. Edit content here only. |
| `data/ui.js` | Interface words (buttons, headings) in both languages |
| `scripts/check-cv.mjs` | Fails the build if a CV section is short or a translation is missing |
| `app/page.js` → `components/desk/` | The desk: `buildDesk.js` (the 3D objects), `idleScreen.js` (what the monitor shows), `DeskScene.js` (camera, clicks, fly-in), `DeskEntry.js` (3D or phone version) |
| `app/[lang]/page.js` | The portfolio inside the monitor, `/en/` and `/ar/` |
| `app/[lang]/work/[slug]/page.js` | One case study per project, per language |
| `components/site/` | Top bar, language switch, theme toggle, before/after slider, Khatt demo, certification filter |
| `app/globals.css` | All styles. Uses logical properties (`inline-start`), so Arabic mirrors without separate CSS |
| `lib/i18n.js` | Arabic digits, month names, and Arabic plural forms ("٦ أشخاص", "٣١ شخصاً") |

## The desk

| Object | Click it to |
| --- | --- |
| Monitor, left half | Enter in English |
| Monitor, right half | Enter in Arabic |
| Disk drive | Download the CV (PDF) |
| Lamp | Switch light/dark mode (the lamp lights up in dark mode) |
| Books | Jump to Research |
| Plant | Jump to Leadership, teaching and volunteering |

The same actions are buttons under the desk, so everything works with a keyboard.

**Phones and browsers without WebGL** get the monitor's idle screen as a plain page
(no 3D download at all). three.js is only loaded when the desk is shown.

**Using your own 3D model**: load it with `GLTFLoader` in `DeskScene.js` instead of
`buildDesk()`, and set `userData.action` on the meshes (`"screen"`, `"drive"`, `"lamp"`,
`"books"`, `"plant"`). The screen mesh needs UVs running left to right so the
English/Arabic halves still work. Compress the file (Draco or meshopt) and check its licence.

## Quality checks done

- `npm run check:cv`: 8 links, 8 highlights, 10 skill groups, 12 experience entries
  (career break included), 8 projects, 4 degrees, 20 certifications (1 in progress,
  3 expired), 10 awards, 2 patents, 6 of 9 publications, 8 of 31 talks, 4 media items,
  6 leadership roles, 5 languages, 4 interests. Every field in English and Arabic.
- axe-core (WCAG 2.2 AA + best practice): no issues on `/en/`, `/ar/` and the case-study
  pages, in light and dark mode, plus the phone idle screen.
- `prefers-reduced-motion`: no typing animation, no camera flight, no cross-fade.
- Tested at 1440×900 and 390×844.

The CV and every name in it are fictional (Portfolio Summit 2026).
