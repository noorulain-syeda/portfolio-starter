import { ui } from "@/data/ui";

export default function SiteFooter({ lang }) {
  return (
    <footer className="footer">
      <div className="wrap" style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: 12 }}>
        <p>{ui.footerNote[lang]}</p>
        <p>{ui.builtWith[lang]}</p>
      </div>
    </footer>
  );
}
